# BinGo APP

Aplikasi ini merupakan output project dari capstone project yang telah dibuat oleh saya dan tim yang meliputi
- Machine Learning untuk modeling
- Cloud Computing untuk pembuatan API
- Mobile development untuk pembuatan aplikasi

# FITUR
- Login
- SignUp
- Edit Profile
- Scan Item melalui Kamera dan Galeri
- Detail hasil dari scan yang dilakukan
