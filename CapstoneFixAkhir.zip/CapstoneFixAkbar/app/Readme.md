# BinGo APP

Aplikasi ini merupakan product dari capstone project yang dilaksanakan pada program BANGKIT ACADEMY

# Fitur

1. Login
2. SignUp
3. Edit Profile
4. Scan Item menggunakan kamera dan galeri
5. menampilkan detail hasil dari scan yang dilakukan


