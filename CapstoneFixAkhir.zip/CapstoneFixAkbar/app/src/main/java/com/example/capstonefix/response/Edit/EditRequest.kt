package com.example.capstonefix.response.Edit

data class EditRequest(
    val username: String,
    val email: String,
    val password: String
)