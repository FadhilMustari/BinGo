package com.example.capstonefix.response.Login

data class loginRequest(
    val email: String,
    val password: String
)