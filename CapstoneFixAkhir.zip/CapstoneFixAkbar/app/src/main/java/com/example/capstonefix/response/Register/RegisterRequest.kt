package com.example.capstonefix.response.Register

data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String
)
